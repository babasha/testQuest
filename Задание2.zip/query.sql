-- Запрос для получения сотрудников всех нижестоящих подразделений
-- от подразделения сотрудника "Сотрудник 1" с id 710253
-- с фильтрацией по возрасту (<40) и исключением подразделений 100055, 100059

WITH 
-- CTE для получения подразделения сотрудника с id 710253
EmployeeSubdivision AS (
    SELECT subdivision_id 
    FROM collaborators 
    WHERE id = 710253
),

-- CTE для получения всех подразделений с уровнями вложенности
SubdivisionHierarchy AS (
    -- Базовый случай: все подразделения верхнего уровня (без родителя)
    SELECT 
        id,
        name,
        parent_id,
        1 as level
    FROM subdivisions 
    WHERE parent_id IS NULL
    
    UNION ALL
    
    -- Рекурсивный случай: подразделения с родителями
    SELECT 
        s.id,
        s.name,
        s.parent_id,
        sh.level + 1
    FROM subdivisions s
    INNER JOIN SubdivisionHierarchy sh ON s.parent_id = sh.id
),

-- CTE для получения всех нижестоящих подразделений от подразделения сотрудника
ChildSubdivisions AS (
    -- Начальное подразделение сотрудника
    SELECT 
        s.id,
        s.name,
        s.parent_id,
        sh.level
    FROM subdivisions s
    INNER JOIN SubdivisionHierarchy sh ON s.id = sh.id
    INNER JOIN EmployeeSubdivision es ON s.id = es.subdivision_id
    
    UNION ALL
    
    -- Все дочерние подразделения
    SELECT 
        s.id,
        s.name,
        s.parent_id,
        sh.level
    FROM subdivisions s
    INNER JOIN SubdivisionHierarchy sh ON s.id = sh.id
    INNER JOIN ChildSubdivisions cs ON s.parent_id = cs.id
),

-- CTE для подсчета количества сотрудников в каждом подразделении
CollaboratorCounts AS (
    SELECT 
        subdivision_id,
        COUNT(*) as colls_count
    FROM collaborators
    GROUP BY subdivision_id
)

-- Основной запрос
SELECT 
    c.id,
    c.name,
    cs.name as sub_name,
    cs.id as sub_id,
    cs.level as sub_level,
    ISNULL(cc.colls_count, 0) as colls_count
FROM collaborators c
INNER JOIN ChildSubdivisions cs ON c.subdivision_id = cs.id
LEFT JOIN CollaboratorCounts cc ON cs.id = cc.subdivision_id
WHERE 
    c.age < 40
    AND cs.id NOT IN (100055, 100059)
    AND c.id != 710253  -- Исключаем самого сотрудника, от подразделения которого ищем
ORDER BY cs.level ASC;